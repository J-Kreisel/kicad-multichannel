"""KiCad IPC adapters."""
